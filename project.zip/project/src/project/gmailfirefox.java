package project;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

//import java.util.concurrent.TimeUnit;

//import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;


public class gmailfirefox {

	public static void main(String[] args) {

		System.setProperty("webdriver.gecko.driver", "C:\\Users\\Dheeraj Kallu\\Downloads\\geckodriver-v0.10.0-win64\\geckodriver.exe");	
		WebDriver driver=new FirefoxDriver();
		//wait 5 secs for  userid to be entered
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
        
        driver.get("http://www.facebook.com");
        driver.findElement(By.id("email")).sendKeys("Dheeraj143");;
        
        
         
        
       
        //Enter Password
        WebElement element1 = driver.findElement(By.id(".//*[@id='pass']"));
        element1.sendKeys("Dheeraj143");
         
        //Submit button
        driver.findElement(By.id(".//*[@id='u_0_n']"));
         
         
        /*WebElement myDynamicElement = (new WebDriverWait(driver, 15)).until(ExpectedConditions.presenceOfElementLocated(By.id("gbg4")));
        driver.findElement(By.id("gbg4")).click();
         
        //press signout button
driver.findElement(By.id("gb_71")).click();   */
         
         
   }
    
    

}
	


